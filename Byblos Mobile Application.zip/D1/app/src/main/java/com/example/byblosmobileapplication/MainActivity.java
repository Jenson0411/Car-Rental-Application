package com.example.byblosmobileapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private EditText name;
    private EditText password;
    private EditText email;
    private EditText role;
    private Button login;
    private Button signIn;

    private String userName="admin";
    private String adminPWS="admin";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onClickButton(View view){

        name=findViewById(R.id.etName);
        password=findViewById(R.id.etPassword);
        email=findViewById(R.id.etEmail);
        role=findViewById(R.id.etRole);
        login=findViewById(R.id.btnLogin);
        signIn=findViewById(R.id.btnSignIn);

        int pressID=view.getId();
        String inputRole=role.getText().toString();
        String inputName=name.getText().toString();
        String inputPSW=password.getText().toString();

        if(pressID==R.id.btnLogin){
            if(isValid(inputName,inputPSW,inputRole)){
                startActivity(new Intent(this,WelcomePage.class));
            }
            else{
                Toast.makeText(MainActivity.this,"Incorrect info entered!",Toast.LENGTH_SHORT);
            }
        }
        else{

        }
    }


    public boolean isValid(String name,String passWord, String role) {
        if (role.equals("Admin") && name.equals(userName) && passWord.equals(adminPWS)) {
            return true;
        }
        return false;
    }
}