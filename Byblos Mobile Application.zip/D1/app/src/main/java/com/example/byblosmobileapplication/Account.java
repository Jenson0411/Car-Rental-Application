package com.example.byblosmobileapplication;

public class Account {
    protected String username;
    protected String email;
    protected String password;
    protected String role;


    public Account(String username, String email, String password, String role){
        this.username = username;
        this.email = email;
        this.password = password;
        this.role = role;
    }
}
