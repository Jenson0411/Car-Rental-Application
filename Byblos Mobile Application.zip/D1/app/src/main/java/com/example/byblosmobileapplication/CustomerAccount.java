package com.example.byblosmobileapplication;

public class CustomerAccount extends Account{

    public CustomerAccount(String username, String email, String password, String role) {
        super(username, email, password, role);
    }


}
