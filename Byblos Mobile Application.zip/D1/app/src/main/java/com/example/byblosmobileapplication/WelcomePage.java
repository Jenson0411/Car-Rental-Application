package com.example.byblosmobileapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class WelcomePage extends AppCompatActivity {

    EditText welcome;
    EditText username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_page);
        welcome=findViewById(R.id.etWelcome);
        //username=findViewById(R.id.etName);

        welcome.setText("Welcome ");
    }




}